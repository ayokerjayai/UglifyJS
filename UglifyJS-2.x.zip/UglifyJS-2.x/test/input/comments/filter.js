// foo
/*@preserve*/
// bar
