var a = bar(1+2);
var b = baz(3+9);
print('q' + 'u' + 'x', a, b);
foo(5+6);
